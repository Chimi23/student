const express = require("express");
const mongoose = require("mongoose");
const studentRouter = require('./routes/student')
const app = express()

app.use(express.json());
app.use(express.urlencoded({ extended:true}));

app.use("/student", studentRouter)



const start = async () => {
    const mongoURI = "mongodb://localhost:27017";

    try{
        await mongoose.connect(mongoURI, {useNewUrlParser: true});
        app.listen(3000, () => console.log('server started'));
    } catch (error){
        console.log("Error starting server", error)
    }  
};

start()